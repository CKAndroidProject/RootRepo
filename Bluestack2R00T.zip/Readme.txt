How to use :-

* Install BS2RT.apk and open,
* Click 'Root' Button,
* Wait 30sec, do not close app,
* Close BlueStacks, Open Task Manager kill Every HD start process,
* Start BlueStacks and install Launcher,
* Open SuperSu, Click update continue Normal,
* Close BlueStacks, Open Task Manager kill Every HD start process,
* Start BlueStacks,
* All Done.

Xda Devlopers : Gorav Gupta