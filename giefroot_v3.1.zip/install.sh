#!/bin/sh

ADBBINARY="./adb.linux"
OS=$(uname)

BASEDIR="$( dirname "$0" )"
cd "$BASEDIR"

chmod +x files/adb.linux
chmod +x files/adb.mac

echo ""
echo "=============================================="
echo "=                                            ="
echo "=                giefroot v3.1               ="
echo "=            created by zxz0O0               ="
echo "=                                            ="
echo "=       Many thanks to:                      ="
echo "=       - [NUT]                              ="
echo "=       - MohammadAG                         ="
echo "=       - Keen Team                          ="
echo "=                                            ="
echo "=============================================="
echo ""

if [ "$OS" = "Linux" ]; then
	ADBBINARY="./adb.linux"
fi
if [ "$OS" = "Darwin" ]; then
	ADBBINARY="./adb.mac"
fi
adb version > /dev/null 2>&1 && { ADBBINARY="adb" && echo "Using local adb"; }
if [ "$ADBBINARY" != "adb" ]; then
	echo "Using $ADBBINARY"
fi
echo ""

cd ./files

if [ "$OS" = "Linux" ]; then
	echo "It looks like you are running Linux"
	echo "Please make sure ia32-libs is installed if you get any errors"
	echo ""
fi

${ADBBINARY} kill-server
${ADBBINARY} start-server

echo "============================================="
echo "Waiting for Device, connect USB cable now..."
echo ""
echo "Make sure that you authorize the connection"
echo "if you get any message on the phone"
echo "============================================="
${ADBBINARY} wait-for-device
echo "Device found!"

echo ""
echo "============================================="
echo "Sending files"
echo "============================================="

${ADBBINARY} push a /data/local/tmp
${ADBBINARY} push getroot /data/local/tmp
${ADBBINARY} push giefroot /data/local/tmp
${ADBBINARY} push modulecrcpatch /data/local/tmp
${ADBBINARY} push systemrw.sh /data/local/tmp
${ADBBINARY} push wp_mod.ko /data/local/tmp
${ADBBINARY} push UPDATE-SuperSU-v2.45.zip /data/local/tmp/SuperSU.zip
${ADBBINARY} push busybox /data/local/tmp
${ADBBINARY} push installsupersu.sh /data/local/tmp

${ADBBINARY} shell "chmod 777 /data/local/tmp/a"
${ADBBINARY} shell "chmod 777 /data/local/tmp/modulecrcpatch"
${ADBBINARY} shell "chmod 777 /data/local/tmp/giefroot"
${ADBBINARY} shell "chmod 777 /data/local/tmp/getroot"
${ADBBINARY} shell "chmod 777 /data/local/tmp/systemrw.sh"
${ADBBINARY} shell "chmod 777 /data/local/tmp/wp_mod.ko"
${ADBBINARY} shell "chmod 777 /data/local/tmp/busybox"
${ADBBINARY} shell "chmod 777 /data/local/tmp/installsupersu.sh"
${ADBBINARY} shell "chmod 777 /data/local/tmp/"
${ADBBINARY} shell "touch /data/local/tmp/giefrootlog"
${ADBBINARY} shell "chmod 777 /data/local/tmp/giefrootlog"

isSupported=`${ADBBINARY} shell "/data/local/tmp/getroot -s &> /dev/null || echo $?" | tr -d '\r\n'`
if [ "$isSupported" = "1" ]; then
	echo ""
	echo Error: Seems your kernel / device is not supported
	${ADBBINARY} shell "/data/local/tmp/getroot -s"
	echo ""
	echo "Press any key to quit"
	read tmpvar
	exit 1
fi

${ADBBINARY} uninstall org.keenteam &> /dev/null
${ADBBINARY} install exploitServiceApp.apk

echo ""
echo "============================================="
echo "Running exploit"
echo 'Make sure you have enabled "Allow mock locations"'
echo "in Developer Settings!"
echo "============================================="
echo Please wait for the device to reboot
${ADBBINARY} shell "/data/local/tmp/giefroot" &> /dev/null
echo "Press any key to continue"
read tmpvar
${ADBBINARY} wait-for-device &> /dev/null
sleep 5
rootCheck=`${ADBBINARY} shell "su -v" | tr -d '\r\n'`
if [ "$rootCheck" = "/system/bin/sh: su: not found" ]; then
	echo "Error: device not rooted"
	echo "Press any key to quit"
	read tmpvar
	exit 1
fi

echo ""
echo "Done. You can now unplug your device."
echo "Enjoy root!"
echo "============================================="
${ADBBINARY} shell "rm /data/local/tmp/a" &> /dev/null
${ADBBINARY} shell "rm /data/local/tmp/systemrw.sh" &> /dev/null
${ADBBINARY} shell "rm /data/local/tmp/getroot" &> /dev/null
${ADBBINARY} shell "rm /data/local/tmp/giefroot" &> /dev/null
${ADBBINARY} shell "rm /data/local/tmp/wp_mod.ko" &> /dev/null
${ADBBINARY} shell "rm /data/local/tmp/modulecrcpatch" &> /dev/null
${ADBBINARY} shell "rm /data/local/tmp/installsupersu.sh" &> /dev/null
${ADBBINARY} shell "rm /data/local/tmp/SuperSU.zip" &> /dev/null
${ADBBINARY} shell "rm /data/local/tmp/memfile" &> /dev/null
${ADBBINARY} uninstall org.keenteam &> /dev/null

${ADBBINARY} kill-server

echo ""
echo "What to do next?"
echo "- Donate to the people involved"
echo "- Install dualrecovery by [NUT]"
echo "- Backup TA partition"
echo ""

echo "Press any key to quit"
read tmpvar
exit 0